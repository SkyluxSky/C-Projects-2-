#include <stdio.h>
#include <stdlib.h>

int main()
{

   int age = 40; /* Integer = A Whole Number  */
   double gpa = 3.0; /* Double = A Decimal  */
   char grade = 'A'; /* Character = A Letter */
   char phrase[] = "This Is A C Program"; /* Create a string of characters using var[] = "Hello World"/ This creates an Array... */




    return 0;
}

#include <stdio.h>
#include <stdlib.h>

/* Array is a container for huge amounts of information,

An Array is a data structure where you can store a large amount of information

Int can create an Array of integers, char can create an Array of characters and double can create an Array of floats  */

int main()
{
    //[] at the end of a variable creates an Array
    int luckyNumers[] = {4, 8, 15, 23, 24, 42};
    luckyNumers[0] = 200; // You can modify an Array normally
    printf("%d", luckyNumers[0]); //each number has an index starting from 0 using []

    int luckyNumbers[10]; //Array potentially can contain x amount of characters
    luckyNumbers[0] = 80;
    luckyNumbers[1] = 90;
    printf("%d", luckyNumbers[0]);

    char phrase[20] = "Array";
    printf("%c", phrase);


    return 0;
}

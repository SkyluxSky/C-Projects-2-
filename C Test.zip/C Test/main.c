#include <stdio.h>
#include <stdlib.h>

int main()
{
    int value;
    printf("Enter in a number:\n");
    scanf("%d", &value);
    printf("Your value is %d", value * 12);

    return 0;
}

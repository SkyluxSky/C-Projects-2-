#include <stdio.h>
#include <stdlib.h>

int main()
{
    char color[20];
    char pluralNoun[20];
    char celebrityF[30];
    char celebrityL[30];

    printf("Enter a color: ");//input 1
    scanf("%s", color);
    printf("Enter a plural noun: ");//input 2
    scanf("%s", pluralNoun);
    printf("Enter a celebrity name: ");//input 3
    scanf("%s%s", celebrityF, celebrityL);


    printf("Roses are %s\n", color);
    printf("%s are blue\n", pluralNoun);
    printf("I love %s %s\n", celebrityF, celebrityL);

    return 0;
}

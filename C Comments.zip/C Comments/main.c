#include <stdio.h>
#include <stdlib.h>

int main()
{
    /*
    This is how to comment Used for TODO, Comments what code does,comment out a line of code, use comments when they are necessary
     */
    /*
    printf("Comments are fun\n");
    */
    printf("Comments are fun\n");

    return 0;
}
